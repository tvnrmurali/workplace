
SQL> CREATE TABLE food_info(foodId VARCHAR2(20),foodPrice NUMBER(5),foodQuantity NUMBER(5),orderDate Date,foodType varchar2(10));


SQL> CREATE SEQUENCE foodId_sequence start with 1000;


SQL>insert into food_info values(foodId_sequence.next_val,?,?,sysdate,?)