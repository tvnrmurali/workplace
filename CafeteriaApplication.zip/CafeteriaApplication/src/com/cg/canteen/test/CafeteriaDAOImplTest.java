package com.cg.canteen.test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.dao.CafeteriaDAOImpl;
import com.cg.canteen.exception.CafeteriaException;

public class CafeteriaDAOImplTest {
	
	
	

	static CafeteriaDAOImpl cafedao;
	static CafeteriaBean bean;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		cafedao = new CafeteriaDAOImpl();
		bean = new CafeteriaBean();
	}

	
	
	
	
	@Test
	public void testADDItems() throws CafeteriaException, IOException
	{

		assertNotNull(cafedao.addItem(bean));
	}
	
	
	
	@Test
	public void testViewItem() throws IOException, CafeteriaException {
		assertNotNull(cafedao.viewItem("1021"));
	}



	@Test
	public void testRetrieveAll() throws IOException, CafeteriaException {
		assertNotNull(cafedao.retrieveAll());
	}
	
	@Ignore
	@Test
	public void testViewItem1() throws CafeteriaException, IOException {
		assertEquals("TestName", cafedao.viewItem("1021").getFoodId());
	}


}
