package com.cg.canteen.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.dao.CafeteriaDAO;
import com.cg.canteen.dao.CafeteriaDAOImpl;
import com.cg.canteen.exception.CafeteriaException;

public class CafeteriaServiceImpl implements CafeteriaService{
	
	CafeteriaDAO cafedao = new CafeteriaDAOImpl();

	@Override
	public String addItem(CafeteriaBean bean) throws IOException, CafeteriaException {
		String data;
		data = cafedao.addItem(bean);
		return data;
	}
	

	@Override
	public CafeteriaBean viewItem(String foodId) throws CafeteriaException, IOException{
		String a = foodId;
		CafeteriaBean bean = cafedao.viewItem(a);
		return bean;
	}
	

	@Override
	public List<CafeteriaBean> retrieveAll() throws IOException, CafeteriaException {
		cafedao = new CafeteriaDAOImpl();
		List<CafeteriaBean> foodList = null;
		foodList = cafedao.retrieveAll();
		return foodList;
	}
	
	

	public void validateItem(CafeteriaBean bean) throws CafeteriaException 
	
	{
		List<String> validationErrors = new ArrayList<String>();
		
		
		if(!(isValidAmount(bean.getFoodPrice())))
		{
			validationErrors.add("\n Amount should be a positive Number \n");
		}
		
		if(!(isValidQuantity(bean.getFoodQuantity())))
		{
			validationErrors.add("\n Quantity should be positive number \n");
		}
		
		if(!isValidItem(bean.getFoodItem()))
		{
			throw new CafeteriaException(validationErrors+"");
		}

		if(!validationErrors.isEmpty())
		{
			throw new CafeteriaException(validationErrors+"");
		}
		
	}
	
	

	private boolean isValidItem(String foodItem) {

		Pattern itemPattern = Pattern.compile("^[A-Z]{1}[a-z]{3,}$");
		Matcher itemMatcher = itemPattern.matcher(foodItem);
		return itemMatcher.matches();
	}
	

	private boolean isValidQuantity(int foodQuantity) {

		return foodQuantity>0;
	}
	
	

	private boolean isValidAmount(float foodprice) {
		return foodprice>0;
	}


}
