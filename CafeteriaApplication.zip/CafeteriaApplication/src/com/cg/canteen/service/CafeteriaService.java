package com.cg.canteen.service;

import java.io.IOException;
import java.util.List;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.exception.CafeteriaException;

public interface CafeteriaService {
	
	public String addItem(CafeteriaBean bean) throws IOException, CafeteriaException;
	public CafeteriaBean viewItem(String foodId) throws CafeteriaException, IOException;
	public List<CafeteriaBean> retrieveAll() throws IOException, CafeteriaException;
	
}
