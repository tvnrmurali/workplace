package com.cg.canteen.bean;

import java.util.Date;

public class CafeteriaBean {
	private String foodId;
	private float foodPrice;
	private int foodQuantity;
	private Date orderDate;
	private String foodItem;
	private float totalBill;
	
	
	
	public String getFoodId() {
		return foodId;
	}
	public void setFoodId(String foodId) {
		this.foodId = foodId;
	}
	public float getFoodPrice() {
		return foodPrice;
	}
	public void setFoodprice(float foodPrice) {
		this.foodPrice = foodPrice;
	}
	public int getFoodQuantity() {
		return foodQuantity;
	}
	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	
	public String getFoodItem() {
		return foodItem;
	}
	public void setFoodItem(String foodItem) {
		this.foodItem = foodItem;
	}
	public float getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(float totalBill) {
		this.totalBill = totalBill;
	}
	
	@Override
	public String toString() {
		return "CafeteriaBean [foodId=" + foodId + ", foodPrice=" + foodPrice + ", foodQuantity=" + foodQuantity
				+ ", orderDate=" + orderDate + ", foodItem=" + foodItem + ", totalBill=" + totalBill + "]";
	}

	
}
