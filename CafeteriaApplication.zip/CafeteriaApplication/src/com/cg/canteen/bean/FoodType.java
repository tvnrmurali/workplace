package com.cg.canteen.bean;

public enum FoodType {
}
