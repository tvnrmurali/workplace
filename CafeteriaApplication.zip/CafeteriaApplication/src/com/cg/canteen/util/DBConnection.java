package com.cg.canteen.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	static Connection con = null;
	public static Connection getConnection() throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("resources/DB.properties");
		
		prop.load(fis);
		
		String driver = prop.getProperty("driver");
		String url = prop.getProperty("url");
		String username = prop.getProperty("username");
		String password = prop.getProperty("password");
		try {
		Class.forName(driver);
		con = DriverManager.getConnection(url, username, password);
		}catch(SQLException | ClassNotFoundException e)
		{
			System.out.println(e);
		}
		return con;
	}

}
