package com.cg.canteen.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.exception.CafeteriaException;
import com.cg.canteen.util.DBConnection;

public class CafeteriaDAOImpl implements CafeteriaDAO{
	
	Logger logger=Logger.getRootLogger();
	
	public CafeteriaDAOImpl() {
	PropertyConfigurator.configure("resources/log4j.properties");

	
	}
	

	@Override
	public String addItem(CafeteriaBean bean) throws IOException, CafeteriaException {
		Connection connection = DBConnection.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String foodId=null;
		int queryResult = 0;

		try
		{
			preparedStatement = connection.prepareStatement(QueryMapper.Add_Details);
			preparedStatement.setFloat(1,(Float) bean.getFoodPrice());
			preparedStatement.setInt(2,bean.getFoodQuantity());
			preparedStatement.setString(3,bean.getFoodItem());
			
			queryResult = preparedStatement.executeUpdate();
			Statement st = connection.createStatement();
			resultSet = st.executeQuery(QueryMapper.View_Details);
			if(resultSet.next())
			{
				foodId=resultSet.getString(1);
			}
			

		if(queryResult==0)
		{
			logger.error("Insertion failed ");
			throw new CafeteriaException("Inserting donor details failed ");

		}
		else
		{
			logger.info("Donor details added successfully:");
			return foodId;
		}
		}catch(SQLException sqle)
		{
			sqle.printStackTrace();
			logger.error(sqle.getMessage());
			throw new CafeteriaException("Technical Problem refer log");
		}
		
	}

	
	

	@Override
	public CafeteriaBean viewItem(String foodId) throws IOException, CafeteriaException {
		
		Connection connection = DBConnection.getConnection();
		String a = foodId;
		CafeteriaBean bean ;
		try {
			PreparedStatement ps = connection.prepareStatement(QueryMapper.View_Details_By_Id);
			ps.setString(1,a);
			
			ResultSet rs = ps.executeQuery();
			if(rs==null)
			{
				logger.error("failed to fetch the data");
				throw new CafeteriaException("fetching food Id failed ");

			}
			else
			{
				logger.info(" details fetched successfully:");
			}
					while(rs.next())
					{
						bean = new CafeteriaBean();
						System.out.println(rs.getString(1));
						System.out.println(rs.getFloat(2));
						System.out.println(rs.getInt(3));
						System.out.println(rs.getDate(4));
						System.out.println(rs.getString(5));
						float foodPrice = rs.getFloat(2);
						int foodQuantity = rs.getInt(3);
						float totalBill = foodPrice*foodQuantity;
						
						System.out.println("Total bill is:"+totalBill);
					}
					
		}catch(SQLException sqle)
		{
			logger.error(sqle.getMessage());
			throw new CafeteriaException("Error in closing db connection");
		}
		return null;
		
	}
	
	
	

	@Override
	public List<CafeteriaBean> retrieveAll() throws IOException, CafeteriaException {

		Connection con=DBConnection.getConnection();
		int itemCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CafeteriaBean> foodList = new ArrayList<CafeteriaBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.View_All_Details);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CafeteriaBean bean=new CafeteriaBean();
				bean.setFoodId(resultset.getString(1));
				bean.setFoodprice(resultset.getFloat(2));
				bean.setFoodQuantity(resultset.getInt(3));
				bean.setOrderDate(resultset.getDate(4));
				bean.setFoodItem(resultset.getString(5));
				foodList.add(bean);
				
				itemCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CafeteriaException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{

				logger.error(e.getMessage());
				throw new CafeteriaException("Error in closing db connection");
			}
		}
		
		if( itemCount == 0)
			return null;
		else
			return foodList;
	}


}
