package com.cg.canteen.dao;

import java.io.IOException;
import java.util.List;

import com.cg.canteen.bean.CafeteriaBean;
import com.cg.canteen.exception.CafeteriaException;

public interface CafeteriaDAO {
	
	public String addItem(CafeteriaBean bean) throws IOException, CafeteriaException;
	public CafeteriaBean viewItem(String foodId) throws IOException, CafeteriaException;
	public List retrieveAll() throws IOException, CafeteriaException;

	
}
