package com.cg.canteen.dao;

public interface QueryMapper {
	
	String Add_Details = "insert into food_info values(foodId_sequence.nextVal,?,?,sysdate,?)";
	String View_Details = "select * from food_info order by foodId";
	String View_Details_By_Id = "Select * from food_info where foodId=?";
	String View_All_Details = "SELECT foodId,foodPrice,foodQuantity,orderDate,foodItem FROM food_info";
	
	
}
