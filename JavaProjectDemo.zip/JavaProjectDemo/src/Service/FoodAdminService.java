package Service;

public interface FoodAdminService {
	public void addFood();
	public void removeFood();
	public void viewAllFood();

}
