package entity1;

public class FoodAdmin {
	
	private int fId;
	private int fPrice;
	private int fQuantity;
	public int getfId() {
		return fId;
	}
	public void setfId(int fid2) {
		this.fId = fid2;
	}
	public float getfPrice() {
		return fPrice;
	}
	public void setfPrice(int fPrice) {
		this.fPrice = fPrice;
	}
	public int getfQuantity() {
		return fQuantity;
	}
	public void setfQuantity(int fQuantity) {
		this.fQuantity = fQuantity;
	}
	
	

}
