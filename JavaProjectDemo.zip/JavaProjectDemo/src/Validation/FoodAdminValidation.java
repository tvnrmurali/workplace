package Validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class FoodAdminValidation {
		public void foodItem(String fid)
		{
			Pattern pattern = Pattern.compile("[A-Z][0-9]{4}");
			Matcher matcher = pattern.matcher(fid);
			System.out.println(matcher.matches());
		}
		public void foodPrice(String fprice)
		{
			Pattern pattern = Pattern.compile("[1-9][0-9]{3,4}");
			Matcher matcher = pattern.matcher(fprice);
			System.out.println(matcher.matches());
		}
		
	}

