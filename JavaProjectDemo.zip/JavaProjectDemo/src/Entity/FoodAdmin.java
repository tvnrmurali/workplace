package Entity;

public class FoodAdmin {
	
	
	
	private String fId;
	private double fPrice;
	private int fQuantity;
	
	
	
	public String getfId() {
		return fId;
	}
	public void setfId(String fId) {
		this.fId = fId;
	}
	public double getfPrice() {
		return fPrice;
	}
	public void setfPrice(String fprice2) {
		this.fPrice = fprice2;
	}
	public int getfQuantity() {
		return fQuantity;
	}
	public void setfQuantity(int fQuantity) {
		this.fQuantity = fQuantity;
	}
	
	
}
