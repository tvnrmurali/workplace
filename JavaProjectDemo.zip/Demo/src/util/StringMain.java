package util;

public class StringMain {
	public static void main(String[] args) {
		 StringBuilder a = new StringBuilder("A");
         StringBuilder b = new StringBuilder("B");
        System.out.println(change(a, b));
      //   a=b;
         System.out.println(a + "," + b);
         System.out.println(a);
				 }

	private static StringBuilder change(StringBuilder a, StringBuilder b) {
		a.append(b);
		b=a;
		return a;
	} 
	}
