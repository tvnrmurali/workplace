package com.multithread.examples;

public class ClassThread1Main {

	public static void main(String[] args) {
		
		Thread t = new Thread(new ClassThread1(),"Thread1");
		Thread t1 = new Thread(new ClassThread1(),"Thread2");
		Thread t2 = new Thread(new ClassThread1(),"Thread3");
		
		t.start();
		try
		{
			t.join(1000);
		}catch(InterruptedException ie)
		{
			System.err.println(ie);
		}
		System.out.println(t2.isAlive());

		t1.start();
		try
		{
			t1.join(1000);
		}catch(InterruptedException ie)
		{
			System.err.println(ie);
		}
		
		t2.start();
		try
		{
			t2.join(1000);
		}catch(InterruptedException ie)
		{
			System.err.println(ie);
		}
		
		System.out.println("All Threads Dead");
		
		System.out.println(t.MIN_PRIORITY);
		System.out.println(t1.MAX_PRIORITY);
		System.out.println(t2.NORM_PRIORITY);
		

	}
}
