package com.multithread.examples;

public class ClassThread1 implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName()+"Thread Start");
		for(int row = 2;row<5;row++)
		{
			for(int num=1;num<=10;num++)
			{
				System.out.print(row*num+" ");
				System.out.print(" ");
			}
		}
		System.out.println(Thread.currentThread().getName()+"Thread Ends");

		
	}

}
