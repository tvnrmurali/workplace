
public class Product {
	int prodectId;
	String productName;
	float productPrice;
	
	public int getProdectId() {
		return prodectId;
	}
	public void setProdectId(int prodectId) {
		this.prodectId = prodectId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product [prodectId=" + prodectId + ", productName=" + productName + ", productPrice=" + productPrice
				+ "]";
	}
	
	
}
