
public class SwitchExample {
	public static void main(String[] args) {
		String currentDay = args[0];
		switch(currentDay)
		{
		case "Monday":
		case "Tuesday":
		case "Wednesday":
			System.out.println("boring");
			break;
		case "Thursday":
			System.out.println("Interest");
			break;
		case "Friday":
			System.out.println("Excited");
			break;
		case "Saturday":
			System.out.println("Outing");
			break;
		case "Sunday":
			System.out.println("Sleep");
			break;
		default:
			System.out.println("Ok");
			break;
		}
	}
}
