
public class DemoReturn {
	public static void main(String[] args) {
		//Democal democal = new Democal();
		//Democal.calVolume();
		
		Product product = new Product();
		product.setProdectId(102);
		product.setProductName("Monitor");
		product.setProductPrice(250);
		
		
		System.out.println(product);
		//System.out.println(product.getProdectId());
	
	}
}
