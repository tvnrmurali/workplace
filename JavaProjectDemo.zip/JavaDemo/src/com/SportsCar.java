package com;

public class SportsCar extends Car {
	public void move()
	{
		System.out.println("Sub class move");
	}
	public int capacity()
	{
		System.out.println("Sub class capacity");
		return 2;
	}
	public String fuel()
	{
		String fuel = "Petrol";
		System.out.println("This is a sub class sports method");
		return fuel;
	}
	public String task()
	{
		return  new String();
	}

}
