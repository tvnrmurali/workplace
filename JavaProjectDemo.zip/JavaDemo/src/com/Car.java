package com;

public class Car {
	public void move()
	{
		System.out.println("Super class move");
	}
	public int capacity()
	{
		System.out.println("Super class capacity");
		return 0;
	}
	public String fuel()
	{
		String fuel = "White_Petrol";
		System.out.println("This is a super class car method");
		return fuel;
	}
	public Object task()
	{
		return new Object();
	}

}
