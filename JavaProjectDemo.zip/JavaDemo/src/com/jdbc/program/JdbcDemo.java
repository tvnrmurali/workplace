package com.jdbc.program;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcDemo {
	public static void main(String[] args) {
		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg724","training724");
				
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("select * from emp");
				while(rs.next())
				{
					System.out.println(rs.getInt(1));
					System.out.println(rs.getString(2));
				}
				
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
