package com.accountTypes;

public class MainCar {
	public static void main(String[] args) {
		Vehicle b = new Benz();
		b.fuel();
		b.transport();
		b.speed();
		//b.capacity();
	}
}
