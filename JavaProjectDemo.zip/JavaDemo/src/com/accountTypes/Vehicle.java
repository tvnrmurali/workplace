package com.accountTypes;

public abstract class Vehicle {
	abstract void speed();
	abstract void fuel();
	public void transport()
	{
		System.out.println("It mainly chooses onroad terrain modes");
	}
}
