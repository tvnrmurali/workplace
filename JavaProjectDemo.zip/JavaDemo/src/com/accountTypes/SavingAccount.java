package com.accountTypes;

import com.account.Account;

public class SavingAccount extends Account{
		int a;
		int b;
		int c;
		int add(int i,int j)
		{
			int result = i+j;
			System.out.println(result);
			return result;
			
		}
		int add(int i,int j,int k)
		{
			int result = i+j+k;
			System.out.println(result);
			return result;
		}
		public static void main(String[] args) {
			SavingAccount sa = new SavingAccount();
			sa.add(3, 5);
			sa.add(3, 4, 4);

		}
	}