package com.accountTypes;

import com.account.Account;

public class CurrentAccount {

}
