package com.accountTypes;

public class Benz extends Vehicle{

	@Override
	void speed() {
		System.out.println("speed is 100kmph in 3.5s");
		
	}

	@Override
	void fuel() {
		System.out.println("This car uses premium petrol");
		
	}
	void capacity() {
		System.out.println("This is 200 hp car");
	}
	
}
