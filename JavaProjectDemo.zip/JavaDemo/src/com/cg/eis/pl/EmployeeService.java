package com.cg.eis.pl;

public interface EmployeeService {
	void getEmployeeDetails(int id, String name, double salary);
	void findIsuranceScheme(double salary);
	void displayDetailsOfAnEmployee();
}
