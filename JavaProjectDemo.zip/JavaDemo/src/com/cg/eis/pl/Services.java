package com.cg.eis.pl;

import com.cg.eis.bean.Employee;

public class Services implements EmployeeService{
	Employee employee=new Employee();
	@Override
	public void getEmployeeDetails(int id, String name, double salary) {
		// TODO Auto-generated method stub
		
		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		if(salary>5000 && salary<20000)
		{
			employee.setDesignation("System Engineer");
		}
		else if(salary>=20000 && salary<40000)
		{
			employee.setDesignation("Programmer");
		}
		else if(salary>=40000)
		{
			employee.setDesignation("Manager");
		}
		else if(salary<5000)
		{
			employee.setDesignation("Clerk");
		}
	}

	@Override
	public void findIsuranceScheme(double salary) {
		// TODO Auto-generated method stub
		if(salary>5000 && salary<20000)
		{
			employee.setInsuranceScheme("Scheme c");
		}
		else if(salary>=20000 && salary<40000)
		{
			employee.setInsuranceScheme("Scheme B");
		}
		else if(salary>=40000)
		{
			employee.setInsuranceScheme("Scheme A");;
		}
		else if(salary<5000)
		{
			employee.setInsuranceScheme("No Scheme");
		}
	}

	@Override
	public void displayDetailsOfAnEmployee() {
		// TODO Auto-generated method stub
		System.out.println("Employee Id: "+employee.getId());
		System.out.println("Employee Name: "+employee.getName());
		System.out.println("Employee Salary: "+employee.getSalary());
		System.out.println("Employee Designation: "+employee.getDesignation());
		System.out.println("Employee Isurance Scheme: "+employee.getInsuranceScheme());
	}

}
