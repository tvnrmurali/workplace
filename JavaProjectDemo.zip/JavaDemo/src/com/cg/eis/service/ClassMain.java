package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.pl.Services;

public class ClassMain {
	 public static void main(String[] args) {
			
		 Scanner sc=new Scanner(System.in);
		 
		 Services services=new Services();
		 System.out.println("Enter employee id:");
		 int id=sc.nextInt();
		 System.out.println("Enter employee name:");
		 String name=sc.next();
		 System.out.println("Enter salary:");
		 double salary=sc.nextDouble();
		 services.getEmployeeDetails(id, name, salary);
		 services.findIsuranceScheme(salary);
		 services.displayDetailsOfAnEmployee();
		 sc.close();
	}
}
