package com.regexpress.Demo;

public class Trainee {
	private int empId;
	private String eName;
	private float eSal;
	
	public Trainee(int empId, String eName, float eSal) {
		super();
		this.empId = empId;
		this.eName = eName;
		this.eSal = eSal;
	}

	@Override
	public String toString() {
		return "Trainee [empId=" + empId + ", eName=" + eName + ", eSal=" + eSal + "]";
	}


	
}
