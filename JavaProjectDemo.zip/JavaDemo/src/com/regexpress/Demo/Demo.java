package com.regexpress.Demo;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Demo {
	void mobileNo(String data)
	{
		Pattern pattern = Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher = pattern.matcher(data);
		System.out.println(matcher.matches());
	}
	void data(String name)
	{
		Pattern pattern = Pattern.compile("[A-Z][a-z]{2,6}");
		Matcher matcher= pattern.matcher(name);
		System.out.println(matcher.matches());
	}
	public static void main(String[] args) {
		String input = "Shop,Mop,Hopping,Chopping";
		Pattern pattern = Pattern.compile("hop");
		Matcher matcher = pattern.matcher(input);
		System.out.println(matcher.matches());
		while(matcher.find())
		{
			System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());
		}
		Demo d = new Demo();
		d.data("murali");
		d.mobileNo("6345678906");
	}
}
