package com.regexpress.Demo;

public class ExceptionDemoMain {
	public static void main(String[] args) {
		ExceptionDemo ed = new ExceptionDemo();
		ed.devide();
	}
}
