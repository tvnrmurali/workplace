package com.regexpress.Demo;

import java.util.Arrays;

public class DemoVarargs {
	public static void main(String[] args) {
		
		int empId[] = {12,23,34,24,56,87,68};
		
		for(int i:empId)
		{
			Arrays.sort(empId);
			System.out.print(i+" ");
			//Arrays.copyOfRange(empId, 3, 7);
			//System.out.print(empId+" ");

		}
		
		System.out.println("Binary Search:"+Arrays.binarySearch(empId, 56));
		
		int id[] = Arrays.copyOf(empId, 10);
		
		for(int j:id)
		{
			System.out.print(j+" ");
		}
	}
	}
