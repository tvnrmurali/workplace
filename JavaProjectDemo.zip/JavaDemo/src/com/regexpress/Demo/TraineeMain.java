package com.regexpress.Demo;

public class TraineeMain {
	public static void main(String[] args) {
		Trainee trainee[] = new Trainee[3];
		
		trainee[0] = new Trainee(166156, "Murali", 32000.0f);
		trainee[1]= new Trainee(166157, "Ramana", 32000.0f);
		trainee[2] = new Trainee(156176, "Srinivas", 32000.7f);

		for(int i=0;i<trainee.length;i++)
		{
			System.out.println(trainee[i]);
		}
		
	}
}
