package com.regexpress.Demo;

import java.util.Scanner;

public class EnumClass {
	 Day day; 
	  
	    public EnumClass(Day day) {
	        this.day = day; 
	    }

	    public void dayIsLike() 
	    { 
	        switch (day) 
	        { 
	        case MONDAY: 
	            System.out.println("Mondays are bad."); 
	            break; 
	        case FRIDAY: 
	            System.out.println("Fridays are better."); 
	            break; 
	        case SATURDAY: 
	        	System.out.println("Saturdays are super");
	        case SUNDAY: 
	            System.out.println("Weekends are best."); 
	            break; 
	        default: 
	            System.out.println("Midweek days are so-so."); 
	            break; 
	        } 
	    } 
	  
	    public static void main(String[] args) 
	    { 
	    	Day day1[]= Day.values();
	    	System.out.println("Enter The day:");

	    	Scanner sc = new Scanner(System.in);
	    	String str = sc.next(); 
	        EnumClass ec = new EnumClass(Day.valueOf(str)); 
	        ec.dayIsLike();
	        for (Day day : day1) 
	        { 
	            System.out.println(day + " at index " + day.ordinal()); 
	        } 
	  
	        
	        sc.close();
	    } 

}
