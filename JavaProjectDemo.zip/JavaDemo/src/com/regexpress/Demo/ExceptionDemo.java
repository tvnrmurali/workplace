package com.regexpress.Demo;

public class ExceptionDemo {
	int a = 23;
	int b = 0;
	int arr[] = new int[2];
	public void devide()
	{
		try {
			arr[2]=26;
			int c = a/b;
			System.out.println(c);
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		catch (ArithmeticException | ArrayIndexOutOfBoundsException aioe ) {
			System.out.println(aioe);

		}
	
	}
}
