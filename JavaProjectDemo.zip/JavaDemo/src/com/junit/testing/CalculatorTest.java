package com.junit.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	Calculator cal = new Calculator();

	@Test
	void testAdd() {
		//fail("Not yet implemented");
		assertEquals(9, cal.add(4, 5));
	}
	
	@Test
	void testSub() {
		//fail("Not yet implemented");
		assertEquals(10, cal.sub(25, 15));
	}
	@Before
	@Test
	void beforetestMul() {
		//fail("Not yet implemented");
		assertEquals(12, cal.mul(3, 4));
	}
	@Test
	void testDiv() {
		//fail("Not yet implemented");
		assertEquals(2, cal.div(4, 2));	
	}
	
	@Before
	@Test
	public static void beforeAdd()
	{
		System.out.println("Dummy");
	}
	
	@After
	@Test
	public static void afterAdd()
	{
		System.out.println("This is dummy1");
	}
	
	@Ignore
	@Test
	public static void ignoreDiv()
	{
		System.out.println("This is dummy2");
	}
	
	@AfterAll
	@Test
	public static void afterAllMul() {
		System.out.println("This is dummy3");
	}
}
