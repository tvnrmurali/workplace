package com.junit.testing;

public class Calculator {
	public int add(int a,int b)
	{
		int c = a+b;
		System.out.println("Addition is :"+c);
		return c;
	}
		public int sub(int a, int b)
	{
		int c = a-b;
		System.out.println("Substraction is :"+c);
		return c;
	}
	public int mul(int a,int b)
	{
		int c = a*b;
		System.out.println("Multiplication is :"+c);
		return c;
	}
	public int div(int a , int b)
	{
		int c = a/b;
		System.out.println("Division is :"+c);
		return c;
	}
}
