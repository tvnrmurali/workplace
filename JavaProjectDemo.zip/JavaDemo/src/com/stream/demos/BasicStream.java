package com.stream.demos;

import java.util.stream.Stream;

public class BasicStream {

	public static void main(String[] args) {
		Stream<String> stream = Stream.of("I","G","A","T"."E");
		stream.forEach(location)->;
	}
	
}
