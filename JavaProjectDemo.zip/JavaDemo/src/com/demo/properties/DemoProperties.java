package com.demo.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;

public class DemoProperties {
	
	
	private static void saveProperties(Properties p,String fileName)
	{
		try 
		{
			OutputStream propsFile = new FileOutputStream("demofile.properties"); 
			p.store(propsFile,"Properties File to the Test Application");;
			propsFile.close();
		
		}catch (IOException ioe)
		{
			System.out.println(ioe);
		}
	}
	
	
	private static Properties loadProperties(String fileName)
	{
		Properties tempProp = new Properties();
		try
		{
			InputStream propsFile = new FileInputStream("demofile.properties");
			tempProp.load(propsFile);
			propsFile.close();
		}catch (IOException ioe)
		{
			System.out.println(ioe);
		}
		return tempProp;
	}
	
	
	private static Properties createDefaultProperties()
	{
		Properties tempProp = new Properties();
		tempProp.setProperty("url", "jdbc:oracle:thin:@10.219.34.3:1521:orcl");
		tempProp.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		tempProp.setProperty("username","trg724");
		tempProp.setProperty("password","training724");
		return tempProp;
	}
	
	
	public static void printProperties(Properties p,String s)
	{
		p.list(System.out);
	}
	
	
	public static void main(String[] args) {
		final String Propfile = "MyApplication.properties";
		Properties myProp;
		Properties myNewProp;
		
		myProp = createDefaultProperties();
		printProperties(myProp,"Newly created (Default) Properties");
		
		saveProperties(myProp, Propfile);
		
		myNewProp=loadProperties(Propfile);
		
		printProperties(myNewProp, "Loaded Properties");
		
		printProperties(myNewProp, "After altering propwerties");
		
		saveProperties(myNewProp,Propfile);
		
		Properties myNewProp1 = loadProperties(Propfile);
		
		Enumeration enProps = myNewProp1.propertyNames();
		
		String key = "";
		String param[];
		param = new String[4];
		int i = 0;
		while(enProps.hasMoreElements())
		{
			key = (String) enProps.nextElement();
			System.out.println(key);
			param[i] = (String) myNewProp1.getProperty(key);
			System.out.println(" "+key+"->"+myNewProp1.getProperty(key));
			i++;
		}
		
	}
}
