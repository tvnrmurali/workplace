package com.lab_six.assignment;

public class Person {
	private String firstName;
	private String lastName;
	
	
	Person()  //Default Constructor
	{
		System.out.println("Default Constructor");
	}
	
	
	Person(String firstName, String lastName)  //Parameterized Constructor
	{
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	void personDetails()
	{
		System.out.println("Person details:");
		System.out.println("----------------");
		System.out.println("First Name:"+firstName);
		System.out.println("Last Name:"+lastName);
		
	}

}
