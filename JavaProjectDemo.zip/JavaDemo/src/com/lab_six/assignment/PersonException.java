package com.lab_six.assignment;

public class PersonException extends Exception{
	public PersonException(String a)
	{
		System.out.println("Wrong input entered, please enter your first name and last name in format"+a);
	}
}
