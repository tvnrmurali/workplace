package com.lab_six.assignment;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		String firstName;
		String lastName;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your First Name:");
		firstName = scanner.nextLine();
		System.out.println("Enter Your Last Name:");
		lastName = scanner.nextLine();
		try
		{
			if(firstName.isEmpty()  || lastName.isEmpty())
			{
				throw new PersonException("First name and last name should not be null");
			}
			else
			{
				Person p = new Person(firstName,lastName);
				p.personDetails();
			}
		}catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}
		scanner.close();
	}

}
