package com.lab_six;

public class CheckException {
	public void checkSalary() {
		EmployeeServiceMain emp = new EmployeeServiceMain();
		Employee emp1 = emp.getEmpDetails();
		if (emp1.salary < 3000) {

			double salary = emp1.salary;
			try {
				throw new EmployeeException("Salary less than 3000 :" + salary);
			} catch (EmployeeException e) {

				System.out.println(e.getMessage());
			}
		} else {
			String scheme = emp.insuranceScheme(emp1.designation, emp1.salary);
			Employee person = new Employee(emp1.id, emp1.name, emp1.designation, scheme, emp1.salary);
			emp.EmpDetails(person);
		}
	}
}
