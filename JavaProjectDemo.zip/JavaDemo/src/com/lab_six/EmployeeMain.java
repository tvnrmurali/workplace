package com.lab_six;

public class EmployeeMain {
public static void main(String[] args) {
		
		CheckException check = new CheckException();
		check.checkSalary();
		EmployeeServiceMain emp = new EmployeeServiceMain();
		Employee emp1 = emp.getEmpDetails();
		String scheme = emp.insuranceScheme(emp1.designation, emp1.salary);
		Employee person = new Employee(emp1.id,emp1.name,emp1.designation,scheme,emp1.salary);
		emp.EmpDetails(person);
}
}
