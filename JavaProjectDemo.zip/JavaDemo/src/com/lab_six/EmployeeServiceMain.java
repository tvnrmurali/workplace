package com.lab_six;

public interface EmployeeServiceMain {
	public Employee getEmpDetails();
	public String insuranceScheme(String designation,double Salary);
	public void EmpDetails(Employee emp);

}
