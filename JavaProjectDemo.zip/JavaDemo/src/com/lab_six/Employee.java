package com.lab_six;

public class Employee {

	public int id;
	public String name, designation, insuranceScheme;
	public double salary;

	public Employee() {

	}

	public Employee(int id, String name, String designation, String insuranceScheme, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", designation=" + designation + ", insuranceScheme="
				+ insuranceScheme + ", salary=" + salary + "]";
	}
	
	
}
