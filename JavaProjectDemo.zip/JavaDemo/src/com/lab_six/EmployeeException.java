package com.lab_six;

public class EmployeeException {
double salary;
	
	public EmployeeException(String message, Throwable msg) {
		super(message, msg);
		// TODO Auto-generated constructor stub
	}
	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
