package com.lab_six;

public class EmployeeService {

public class ExcEmployeeServiceMain implements ExcEmployeeService {
	
	@Override
	public ExcEmployee getEmpDetails() {
		String designation;
		String insuranceScheme = null;
		Scanner in = new Scanner(System.in);
		
		System.out.println(" Enter employee id");
		int id = in.nextInt();
		System.out.println(" Enter employee salary");
		double salary = in.nextDouble();
		System.out.println(" Enter employee name");
		String name = in.next();
		in.close();
		if(salary<5000){
			designation = "Clerk";
		}
		else if(salary>5000&&salary<20000){
			designation = "System Associate";
		}
		else if(salary>=20000&&salary<40000){
			designation = "Programmer";
		}
		else{
			designation = "Manager";
		}
		
		ExcEmployee emp = new ExcEmployee(id,name,designation,insuranceScheme,salary);
		return emp;
			
		}

	@Override
	public String insuranceScheme(String designation,double salary) {
		String scheme;
		if(designation == "Clerk")
			scheme = "No Scheme";
		else if(designation == "System Associate")
			scheme = "Scheme C";
		else if(designation == "Programmer")
			scheme = "Scheme B";
		else
			scheme = "Scheme A";
		return scheme;
	}

	@Override
	public void EmpDetails(ExcEmployee emp) {
	    System.out.println(emp);
		
	}
}
