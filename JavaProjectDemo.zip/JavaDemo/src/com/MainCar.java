package com;

public class MainCar {
	public static void main(String[] args) {
		SportsCar sc = new SportsCar();
		sc.capacity();
		sc.move();
		String fuel=sc.fuel();
		System.out.println(fuel);
	}
}
