package com.fileexample_programs;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class WriteFile {
	public static void main(String[] args) throws IOException {

	
	FileOutputStream fos = new FileOutputStream("C:\\Users\\vthuttag\\Desktop\\Java_launch\\JavaDemo\\murali.txt");
	String val = "data is given";
	byte arr[] = val.getBytes();
	fos.write(arr);
	fos.close();
	FileInputStream fis = new FileInputStream("C:\\\\Users\\\\vthuttag\\\\Desktop\\\\Java_launch\\\\JavaDemo\\\\murali.txt");
	int i = 0;
	while((i=fis.read())!=-1)
	{
		System.out.print((char)i);
	}
	fis.close();
}
}
