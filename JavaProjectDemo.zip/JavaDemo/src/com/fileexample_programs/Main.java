package com.fileexample_programs;

import com.account.Account;
import com.accountTypes.SavingAccount;

public class Main extends Account {
	int data=123;
	public void sdetails()
	{
		System.out.println(super.data);
	}
	public static void main(String[] args) {
		Main main = new Main();
		System.out.println(main.data);
		main.sdetails();
	}
}
