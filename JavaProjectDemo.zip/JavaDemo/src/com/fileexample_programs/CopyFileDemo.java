package com.fileexample_programs;

import java.io.FileReader;
import java.io.FileWriter;

public class CopyFileDemo {
	public static void main(String[] args) {
		try (FileReader inputStream = new FileReader("C:\\Users\\vthuttag\\Desktop\\Java_launch\\JavaDemo\\murali.txt");FileWriter outputStream = new FileWriter("C:\\Users\\vthuttag\\Desktop\\Java_launch\\JavaDemo\\murali.txt");){
			int c;
			while((c = inputStream.read())!=-1)
			{
				outputStream.write(c);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
	}
}
