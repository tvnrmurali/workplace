package com.fileexample_programs;

import java.io.Serializable;

public class Product implements Serializable{
	private int pId;
	private String pName;
	private float pPrice;
	
	
	public Product(int pId, String pName, float pPrice) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pPrice = pPrice;
	}


	@Override
	public String toString() {
		return "Product [pId=" + pId + ", pName=" + pName + ", pPrice=" + pPrice + "]";
	}
	
	
	
}
