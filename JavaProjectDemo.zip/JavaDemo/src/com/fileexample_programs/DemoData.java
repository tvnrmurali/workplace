package com.fileexample_programs;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class DemoData {
	public static void main(String[] args) throws IOException {
		
	FileOutputStream fos = new FileOutputStream("C:\\Users\\vthuttag\\Desktop\\Java_launch\\JavaDemo\\murali.txt");
	DataOutputStream dos = new DataOutputStream(fos);
	
	dos.writeInt(Integer.MAX_VALUE);
	dos.write(Byte.MIN_VALUE);
	dos.writeBoolean(Boolean.TRUE);
	dos.writeDouble(Double.MAX_VALUE);
	dos.writeLong(Long.MAX_VALUE);
	dos.close();
	
	FileInputStream fis = new FileInputStream("C:\\Users\\vthuttag\\Desktop\\Java_launch\\JavaDemo\\murali.txt");
	DataInputStream dis = new DataInputStream(fis);
	
	System.out.println(dis.readInt());
	System.out.println(dis.readLong());
	System.out.println(dis.readBoolean());
	System.out.println(dis.readByte());
	System.out.println(dis.readDouble());
	dis.close();
}
}
