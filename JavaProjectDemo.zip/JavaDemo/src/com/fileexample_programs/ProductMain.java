package com.fileexample_programs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ProductMain {
	public static void main(String[] args) throws IOException {
		
		try(FileOutputStream fos = new FileOutputStream("Product");ObjectOutputStream oos = new ObjectOutputStream(fos);)
		{
			Product p = new Product(123, "soap", 2234);
			oos.writeObject(p);
			
		}catch(Exception e)
		{
			System.err.println(e);
		}
		try(FileInputStream fis = new FileInputStream("Product");ObjectInputStream ois = new ObjectInputStream(fis);)
		{
			Product p1 =(Product)ois.readObject();
			System.out.println(p1);
		}catch(Exception d)
		{
			System.err.println(d);
		}
	}
}
