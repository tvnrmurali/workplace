package com.nine_assignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateDemoTest {

	@Test
	public void testGetDay() {
		//fail("Not yet implemented");
		
	}

	@Test
	public void testGetMonth() {
		//fail("Not yet implemented");
	}

	@Test
	public void testGetYear() {
		//fail("Not yet implemented");
	}

}
