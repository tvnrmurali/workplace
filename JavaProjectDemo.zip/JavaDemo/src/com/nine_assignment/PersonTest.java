package com.nine_assignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonTest {

	@Test
	public void testgetFullName() {
		//fail("Not yet implemented");
		System.out.println("From PersonTest");
		Person per = new Person("dummy","devil");
		assertEquals("dummydevil",per.getFullName());
	}
	@Test(expected = IllegalArgumentException.class)
	public void testNullslnName()
	{
		System.out.println("form Person Test testing exceptions");
		Person per1 = new Person(null,null);
	}

}
