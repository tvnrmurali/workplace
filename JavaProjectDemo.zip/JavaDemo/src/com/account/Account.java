package com.account;

public class Account {
	final int data=123;

	public void display()
	{
		data ++;
	}
	
	


}
