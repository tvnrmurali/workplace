package com.lab_four.assignment;

public class KathyAccount {

	 private long accNum;
	  private double balance=3000;
	  private Kathy accHolder;
	  
	public KathyAccount(Kathy accHolder) {
		this.accHolder = accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	 public Kathy getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Kathy accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double money)
	 {
		 balance=balance+money;
		 
	 }
	 public void withdraw(double money1)
	 {
		 balance=balance-money1;
		 
	 }
	 
}
