package com.lab_four.assignment;

import java.util.Scanner;

public class AccountMain1 {
public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("1.Savings Account.");
		System.out.println("2.Current Account");
		System.out.println("Enter your choice:");
		int choice=scanner.nextInt();
		SavingsAccount savingsAccount=new SavingsAccount();
		CurrentAccount currentAccount=new CurrentAccount();
		switch(choice)
		{
		case 1:
			System.out.println("Enter the money you want to debit:");
			double balance=scanner.nextDouble();
			savingsAccount.withdraw(balance);
			break;
		case 2:
			System.out.println("Enter the money you want to debit:");
			double balance1=scanner.nextDouble();
			currentAccount.withdraw(balance1);
			break;
		default:
			break;
			
		}
		scanner.close();
	}
}
