package com.lab_four.assignment;

public class SmithAccount {
	 
	  private long accNum;
	  private double balance=2000;
	  private Smith accHolder;
	  
	public SmithAccount(Smith accHolder) {
		
		this.accHolder = accHolder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	 public Smith getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Smith accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double money)
	 {
		 balance=balance+money;
		 
	 }
	 public void withdraw(double money1)
	 {
		 balance=balance+money1;
		 
	 }
}
