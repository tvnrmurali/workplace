package com.lab_four.assignment;

public class CurrentAccount {

	final double overDraftLimit=1000;
	double currentBalance=2000;
	public void withdraw(double balance)
	{
		currentBalance=currentBalance-balance;
		if(currentBalance<overDraftLimit)
		{
			System.out.println("If you withdraw this money your min over draft balance will under 500!!");
			System.out.println("Sorry!! You can't withdraw this amount.");
		}
		else if(currentBalance==overDraftLimit)
		{
			System.out.println("Your over draft limit reached, deposit money else you can't transact after this!!");
		}
		else
		{
			System.out.println("Current balance:"+currentBalance);
		}
	}
}
