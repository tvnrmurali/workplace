package com.lab_four.assignment;

public class Account {
	 double currentBalance=0;
		public void withdarw(double balance)
		{
			currentBalance=currentBalance-balance;
			System.out.println("Current Balance is: "+currentBalance);
		}
}
