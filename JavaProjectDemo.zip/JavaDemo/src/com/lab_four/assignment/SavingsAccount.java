package com.lab_four.assignment;

public class SavingsAccount extends Account{

	final double minBalance=500;
	double currentBalance=1000;
	public void withdraw(double balance)
	{
		currentBalance=currentBalance-balance;
		if(currentBalance<minBalance)
		{
			System.out.println("If you withdraw this money your min account balance will under 500!!");
			System.out.println("Sorry!! You can't withdraw this amount.");
		}
		else if(currentBalance==minBalance)
		{
			System.out.println("Your min balance reached, deposit money else you can't transact after this!!");
		}
		else
		{
			System.out.println("Current balance:"+currentBalance);
		}
	}
}
