package com.lab_four.assignment;

import java.util.Random;
import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		Smith smith=new Smith();
		SmithAccount smithAccount=new SmithAccount(smith);
		Random rand = new Random();
		long accNum = rand.nextInt(100000) + 1;
		smithAccount.setAccNum(accNum);
		System.out.println("Account Holder Name:"+smithAccount.getAccHolder());
		System.out.println("Account no:"+smithAccount.getAccNum());
		System.out.println("Current Balance:"+smithAccount.getBalance());
		System.out.println("Enter the balance you want to deposit:");
		double money=scanner.nextDouble();
		smithAccount.deposit(money);
		System.out.println("Current Balance:"+smithAccount.getBalance());
		System.out.println();
		Scanner scanner1=new Scanner(System.in);
		Kathy kathy=new Kathy();
		KathyAccount kathyAccount=new KathyAccount(kathy);
		Random rand1 = new Random();
		long accNum1 = rand1.nextInt(100000) + 1;
		kathyAccount.setAccNum(accNum1);
		System.out.println("Account Holder Name:"+kathyAccount.getAccHolder());
		System.out.println("Account no:"+kathyAccount.getAccNum());
		System.out.println("Current Balance:"+kathyAccount.getBalance());
		System.out.println("Enter the balance you want to withdraw:");
		double money1=scanner1.nextDouble();
		kathyAccount.withdraw(money1);
		System.out.println("Current Balance:"+kathyAccount.getBalance());
		scanner.close();
		scanner1.close();
	}
}
