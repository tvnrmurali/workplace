package com.lab_three.assignment;

import java.util.Scanner;

public class Prob3_3main {
	public static void main(String[] args) {
		int year, month, date;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the year in 'YYYY' format:");
		year=scanner.nextInt();
		System.out.println("Enter the month in number in 'MM' format:");
		month=scanner.nextInt();
		System.out.println("Enter the date in'DD' format:");
		date=scanner.nextInt();
		Prob3_3 prob = new Prob3_3();
		prob.duration(year, month, date);
		scanner.close();
	}
}
