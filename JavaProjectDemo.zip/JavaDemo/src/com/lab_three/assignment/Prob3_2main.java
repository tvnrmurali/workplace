package com.lab_three.assignment;

import java.util.Scanner;

public class Prob3_2main {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the string:");
		String string=scanner.nextLine();
		Prob3_2 prob = new Prob3_2();
		
		boolean b=prob.positiveString(string);
		System.out.println(b);
		scanner.close();
	}
}
