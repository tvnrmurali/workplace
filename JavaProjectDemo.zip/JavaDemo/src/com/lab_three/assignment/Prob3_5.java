package com.lab_three.assignment;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Prob3_5 {
	public void expiry(String name,int month,int years) {
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localdate=LocalDate.parse(name,formatter);
		
		System.out.println("Purchased date:"+localdate);
		LocalDate local1=localdate.plusMonths(month);
		LocalDate local2=local1.plusYears(years);
		System.out.println("Expiry date"+local2);
	}


	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter product purchase date:");
		String date=scan.nextLine();
		System.out.println("enter warranty duration in months and years");
		int month=scan.nextInt();
		int years=scan.nextInt();
		Prob3_5 prob =new Prob3_5();
		prob.expiry(date, month, years);
		scan.close();
	}

	}
