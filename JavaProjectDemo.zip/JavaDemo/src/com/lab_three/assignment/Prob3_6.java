package com.lab_three.assignment;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Prob3_6 {
	public void zone(String zoneId)
	{
		ZonedDateTime date=ZonedDateTime.now(ZoneId.of(zoneId));
		System.out.println(date);
	}

public static void main(String[] args) {
	Prob3_6 prob = new Prob3_6();
	prob.zone("America/New_York");
	prob.zone("Europe/London");
	prob.zone("Asia/Tokyo");
	prob.zone("US/Pacific");
	prob.zone("Africa/Cairo");
	prob.zone("Australia/Sydney");
}

}
