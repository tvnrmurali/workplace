package com.lab_three.assignment;

public class Prob3_2 {
	public boolean positiveString(String string) {
		// TODO Auto-generated method stub
		for(int i=0;i<=string.length()-1;i++)
		{
			for(int j=i+1;j<=string.length()-1;j++)
			{
				if(string.charAt(i)<string.charAt(j))
				{
					return true;
				}
				else
				{
					return false;
				}
				
			}
		}
		return true;
	}

}
