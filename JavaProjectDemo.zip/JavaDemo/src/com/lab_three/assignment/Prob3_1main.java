package com.lab_three.assignment;

import java.util.Scanner;

public class Prob3_1main {
	public static void main(String[] args) {
		Prob3_1 p2 = new Prob3_1();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the name");
		String name=sc.next();
		int num=sc.nextInt();
		System.out.println(p2.hello(name, num));
		sc.close();
	}

}
