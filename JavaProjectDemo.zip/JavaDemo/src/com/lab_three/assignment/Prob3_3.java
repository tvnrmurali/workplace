package com.lab_three.assignment;

import java.time.LocalDate;
import java.time.Period;

public class Prob3_3 {
	void duration(int year, int month,int date)
	{
		LocalDate pdate = LocalDate.of(year, month, date);
        LocalDate now = LocalDate.now();
        Period diff = Period.between(now,pdate);
        System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", diff.getYears(), diff.getMonths(), diff.getDays());

	}
}
