package com.lab_three.assignment;

public class Prob3_1 {
	public String hello(String name, int a )
	{
		String b ="";
		switch(a)
		{
		case 1:
			b= name.concat(name);
			break;
		case 2:
			char[] ch = name.toCharArray();
			for(int i=0;i<ch.length;i++)
			{
				if(i%2==0)
				{
					String c = "#";
					b+=c;
				}
				else
				{
					b=b+ch[i];
				}
			}
			break;
		case 3:
			char[] ch1 = name.toCharArray();
			int count=0;
			for(int i=0;i<ch1.length;i++)
			{
				for(int j=i+1;j<ch1.length;j++)
				{
					if(ch1[i]==ch1[j])
					{
						count++;
						break;
					}
				}
				if(count==0)
				{
					b+=ch1[i];
				}
			}
			break;
		case 4:
			char[] ch2=name.toCharArray();
			for(int i=0;i<ch2.length;i++)
			{
				if(!(i%2==0))
				{
					b =b+ch2[i];
				}
				else
				{
					b=b+Character.toString(ch2[i]).toUpperCase();
				}
			}
			break;
		default:
				break;
		}
		return b;
	}
}
