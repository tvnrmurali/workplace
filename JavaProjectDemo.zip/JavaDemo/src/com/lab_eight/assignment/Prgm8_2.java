package com.lab_eight.assignment;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Prgm8_2 
{
public static void main(String[] args) throws IOException 
{
	File f=new File("C:\\Users\\vthuttag\\Desktop\\test\\number.txt");
	Scanner sc=new Scanner(f).useDelimiter(",");
	
FileInputStream fis=new FileInputStream(f);
DataInputStream dis=new DataInputStream(fis);
//BufferedReader br = new BufferedReader(new InputStreamReader(dis));
System.out.println("enter the number:");

while(sc.hasNext())
{
	int  num = sc.nextInt(); 
	if(num%2==0)
	{
   
    System.out.println(num);
	}
    }
sc.close();
}
}

