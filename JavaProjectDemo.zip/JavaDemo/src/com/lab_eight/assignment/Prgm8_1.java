package com.lab_eight.assignment;


import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Prgm8_1 
{
	public static void main(String[] args) throws IOException
{
		FileInputStream fis = new FileInputStream("C:\\Users\\vthuttag\\Desktop\\test\\name.txt");
		DataInputStream dis = new DataInputStream(fis);
		BufferedReader br = new BufferedReader(new InputStreamReader(dis));
		String str;
		while ((str = br.readLine()) != null)
		{
			String[] words = str.split(" ");
			for (String a : words) {
				StringBuilder builder = new StringBuilder(a);
				System.out.print(builder.reverse().toString());
			}
		}
	}
}
