package com.interface_Class;

public class AgeException extends Exception {

	public AgeException(String age) {
		super();
		System.out.println(age);
		// TODO Auto-generated constructor stub
	}
	
}
