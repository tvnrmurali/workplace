package com.interface_Class;

import java.util.Scanner;

public class AgeMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the age");
		int age = sc.nextInt();
		
		try
		{
			if(age<15)
			{
				throw new AgeException("Invalid age");
			}
			else
			{
				System.out.println("valid age");
			}

		}catch (AgeException ag)
		{
			ag.printStackTrace();
		}
		sc.close();
	}
}
