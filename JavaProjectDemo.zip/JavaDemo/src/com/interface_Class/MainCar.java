package com.interface_Class;

public class MainCar {
	public static void main(String[] args) {
		Car c = new Car();
		c.fuel();
		c.speed();
		c.brake();
		c.accelarate();
		c.colorTone();
		int a =VehicleUpdateModify.a;
		System.out.println(a);
	}

}
