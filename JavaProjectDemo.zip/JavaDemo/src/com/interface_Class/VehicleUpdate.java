package com.interface_Class;

public interface VehicleUpdate extends VehicleModify{
	void brake();
	default void tires()
	{
		System.out.println("Tires are bigger");
	}
	
}
