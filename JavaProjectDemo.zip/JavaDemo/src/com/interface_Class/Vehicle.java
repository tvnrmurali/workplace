package com.interface_Class;

public interface Vehicle {
	void speed();
	void fuel();
	void brake();
	default void tires()
	{
		System.out.println("Tires are bigger");
	}
	
	static void seats()
	{
		System.out.println("seats are premium");
	}
}
