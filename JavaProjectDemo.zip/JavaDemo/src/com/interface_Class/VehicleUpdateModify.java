package com.interface_Class;

public interface VehicleUpdateModify {
	int a = 20;;
	void colorTone();
}
