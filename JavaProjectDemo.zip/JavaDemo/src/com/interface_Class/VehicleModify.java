package com.interface_Class;

public interface VehicleModify {
	void accelarate();
}
