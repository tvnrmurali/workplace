package com.interface_Class;

public class Car implements Vehicle,VehicleUpdate,VehicleUpdateModify {

	@Override
	public void speed() {
		// TODO Auto-generated method stub
		System.out.println("Speed is over 100kmph");
		
	}

	@Override
	public void fuel() {
		// TODO Auto-generated method stub
		System.out.println("diesel version");
		
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("Breaks are failed");
		
	}

	@Override
	public void accelarate() {
		// TODO Auto-generated method stub
		System.out.println("Accelaration is very good");
		
	}

	@Override
	public void colorTone() {
		// TODO Auto-generated method stub
		System.out.println("color is premium");
		
	}

	@Override
	public void tires() {
		// TODO Auto-generated method stub
		System.out.println("hi");
	}
	public void seats() {
		
	}
}
