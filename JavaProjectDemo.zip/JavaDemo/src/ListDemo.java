import java.util.ArrayList;
import java.util.Iterator;
//import java.util.ListIterator;

public class ListDemo {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("alpha");
		al.add("Beta");
		al.add("Collection");
		al.add("Collection");
		//System.out.println(al.iterator());
		System.out.println(al);
		System.out.println(al.contains("Beta"));
		al.remove("Beta");
		System.out.println(al.contains("Beta"));
		System.out.println(al.lastIndexOf("Collection"));
		Iterator<String> i = al.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		}
}
