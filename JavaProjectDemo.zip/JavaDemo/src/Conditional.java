
public class Conditional {
	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 20;
		if(num1>num2)
		{
			System.out.println("Number 1 is greater and the number is:"+num1);
		}
		else {
			System.out.println("Number 2 is greater and the number is:"+num2);
		}
	}
}
