import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class ZoneddateTimeDemo {
	public static void main(String[] args) {
		ZonedDateTime currentTime = ZonedDateTime.now();
		System.out.println("India:"+currentTime);
		System.out.println(currentTime.now(ZoneId.of("Europe/Paris")));
		
		DateTimeFormatter formatter  = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		DateTimeFormatter formatter1 = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		DateTimeFormatter formatter2 = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		DateTimeFormatter formatter3 = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		DateTimeFormatter formatter4 = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		
		LocalDate ld1 = LocalDate.now();
		System.out.println(ld1);
		
		System.out.println(ld1.format(formatter));
		System.out.println(ld1.format(formatter1));
		System.out.println(ld1.format(formatter2));
		System.out.println(ld1.format(formatter3));
		System.out.println(ld1.format(formatter4));
		
		LocalDate dob = LocalDate.of(1996, Month.JUNE, 02);
		Period period = dob.until(ld1);
		
		System.out.println(period.getYears());
		System.out.println(period.getMonths());
		System.out.println(period.getDays());
	}
}
