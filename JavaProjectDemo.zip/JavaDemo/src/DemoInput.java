import java.util.Scanner;

public class DemoInput {
	
	public static void main(String[] args) {
		int upperCharCount = 0;
		int lowerCharCount = 0;
		Scanner scanner = new Scanner(System.in);
		while(true)
		{
		System.out.println("what is your name?");
		String input = scanner.nextLine();
		if(!(input.isEmpty()))
		{
			for(char ch:input.toCharArray())
			{
				if(!Character.isDigit(ch) && Character.isAlphabetic(ch))
				{
					if(Character.isUpperCase(ch))
					{
						upperCharCount++;
					}
					else
					{
						lowerCharCount++;
					}
				}
			}
			System.out.println(lowerCharCount);
			System.out.println(upperCharCount);
			break;
		}
		System.out.println("Your name is:"+input);
		}
		scanner.close();
	}

}
