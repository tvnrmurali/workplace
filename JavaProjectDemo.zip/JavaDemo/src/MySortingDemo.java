import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class MySortingDemo {
	public static void main(String[] args) {
		ArrayList<MyStudent> al = new ArrayList<MyStudent>();
		NameComparator name = new NameComparator();
		
		
		al.add(new MyStudent(21, 1234, "Ram"));
		al.add(new MyStudent(13, 4235, "Murali"));
		al.add(new MyStudent(20, 2435, "Siva"));
		al.add(new MyStudent(14, 4352, "Balu"));
		Collections.sort(al, new NameComparator());

		Iterator<MyStudent> i = al.iterator();
		while(i.hasNext())
		{
			MyStudent str = i.next();
			System.out.println(str.name);
		}
		

		//for(Student i:al)
		//{
		//	System.out.println(i.age);
		//}
		
		//System.out.println("After sorting");
		
		//Collections.sort(al);
		//for(Student i:al)
		//{
		//	System.out.println(i.age);
		//}
		
	}
}
