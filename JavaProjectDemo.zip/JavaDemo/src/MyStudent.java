
public class MyStudent {
	int age;
	int id;
	String name;
	public MyStudent(int age, int id, String name) {
		super();
		this.age = age;
		this.id = id;
		this.name = name;
	}
	
	
}
