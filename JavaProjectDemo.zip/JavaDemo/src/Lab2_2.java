
public class Lab2_2 {
	public static void main(String[] args) {
		int number = Integer.parseInt(args[0]);
		if(number>0)
		{
			System.out.println("Positive Number");
		}
		else
		{
			System.out.println("Negative Number");
		}
	}
}
