import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class SortingDemo {
	public static void main(String[] args) {
		ArrayList<Student> al = new ArrayList<Student>();
		al.add(new Student(21, 1234, "Student1"));
		al.add(new Student(13, 4235, "Student2"));
		al.add(new Student(20, 2435, "Student3"));
		al.add(new Student(14, 4352, "Student4"));
		for(Student i:al)
		{
			System.out.println(i.age);
		}
		
		System.out.println("After sorting");
		
		Collections.sort(al);
		for(Student i:al)
		{
			System.out.println(i.age);
		}
		
	}
}
