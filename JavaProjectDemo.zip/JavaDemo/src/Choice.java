
public enum Choice {
	
	M,F;
	
	
	
	
}
