import java.time.LocalDate;
import java.time.Month;
public class LocalDateDemo {
	public static void main(String[] args) {
		LocalDate ld = LocalDate.now();
		System.out.println(ld);
		LocalDate independanceday = LocalDate.of(1947, Month.AUGUST, 15);
		System.out.println(ld.isLeapYear());
		System.out.println(ld.plusDays(10));
		System.out.println(ld.minusDays(10));
		System.out.println(ld.withDayOfMonth(30));
		System.out.println(ld.lengthOfMonth());
	}
}
