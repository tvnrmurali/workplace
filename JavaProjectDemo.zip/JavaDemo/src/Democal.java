import static java.lang.Math.*;
public class Democal {
	double height;
	double length;
	double width;
	static int count;
	
	
	
	public Democal() {
		this(2.34);
		//super();
		count++;
		System.out.println("default constructor");
	}

	

	public Democal(double height, double length, double width) {
		super();
		this.height = height;
		this.length = length;
		this.width = width;
		System.out.println("3 param");
		count++;

	}
	
	



	public Democal(double width) {
		
		this(3.23,4.54,4.76);
		
		//super();
		this.width = width;
		System.out.println("Helloo this is single paramaterixed condtructor");
		count++;

	}



	static double calVolume()
	{
		System.out.println(count);
		// return height*length*width;
		 System.out.println(sqrt(7.7));

		 return 2;
		 
		 
	}
	
	
}
