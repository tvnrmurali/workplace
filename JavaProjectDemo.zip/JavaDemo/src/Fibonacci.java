
public class Fibonacci {
	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		int n1=0, n2=1;
		System.out.println("Upto"+n+":");
		while(n1<= n)
		{
			System.out.println(n1+" ");
			int sum=n1+n2;
			n1=n2;
			n2=sum;
			
		}
		
		
	}
}
