import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ParsingDate {
	public static void main(String[] args) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter date in dd/MM/YYYY format:");
		String input = scanner.nextLine();
		
		LocalDate enteredDate = LocalDate.parse(input, formatter);
		System.out.println("Entered Date:"+enteredDate);
		LocalDate dob = LocalDate.of(1996, Month.JUNE, 02);
		LocalDate ld1 = LocalDate.now();
		Period period = ld1.until(ld1);
		System.out.println(period.getYears());
		System.out.println(period.getMonths());
		System.out.println(period.getDays());
		scanner.close();
	}
}
