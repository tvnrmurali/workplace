package two;

import java.util.Scanner;

public class Person2_4Main {
	public static void main(String[] args) {
		Person2_4 person = new Person2_4("Arun","Kumar",'M');
		Scanner scanner = new Scanner(System.in);
		int phNo = scanner.nextInt();
		person.person1Details();
		person.setphNo(phNo);
		scanner.close();
	}


}
