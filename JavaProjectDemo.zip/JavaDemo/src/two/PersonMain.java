package two;

public class PersonMain {
	public static void main(String[] args) {
		Person person = new Person("Arun","Kumar",'M');
		person.personDetails();
	}

}
