package two;

public class PhoneNumber {
	private String firstName;
	private String lastName;
	private long phNo;
	
	public long phNO(long phNO)
	{
		return phNO;
	}
	
	enum Gender
	{
		M,F;
	}
	
	public PhoneNumber(String firstName,String lastName)
	{
		this.firstName = firstName;
		this.lastName = lastName;
	}
	 public PhoneNumber()
	 {
		 
	 }

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	

}
