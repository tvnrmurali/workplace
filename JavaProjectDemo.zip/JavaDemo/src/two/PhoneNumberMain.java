package two;

import java.util.Scanner;

import two.PhoneNumber.Gender;

public class PhoneNumberMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Your Ph No:");
		long phNo = scanner.nextLong();
		PhoneNumber ph = new PhoneNumber();
		ph.setFirstName("Arun");
		ph.setLastName("Nair");
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println("FirstName:"+ph.getFirstName());
		System.out.println("Last Name:"+ph.getLastName());
		Gender g = Gender.M;
		System.out.println("Gender:"+g);
		//System.out.println(ph.getGender());
		System.out.println("PHNO:"+ph.phNO(897578975));
	}
}
