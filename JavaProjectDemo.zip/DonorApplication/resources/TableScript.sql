
SQL> CREATE TABLE Donor_Details(Donor_id VARCHAR2(20),Name VARCHAR2(20),Address VARCHAR2(20),Phone_Number VARCHAR2(20),Donor_Date DATE,Donor_Amount NUMBER);


SQL> create SEQUENCE donorId_sequenc start with 1000;


SQL>insert into Donor_Details values(donorId_sequenc.next_val,?,?,?,sysdate,?)