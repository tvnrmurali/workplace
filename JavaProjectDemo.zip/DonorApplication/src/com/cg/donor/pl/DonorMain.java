package com.cg.donor.pl;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;
import com.cg.donor.service.DonorServiceImpl;
import com.cg.donor.service.IDonorService;

public class DonorMain {
	
	static Scanner sc = new Scanner(System.in);
	static IDonorService donorService = null;
	static DonorServiceImpl donorServiceImpl = null;
	
	public static void main(String[] args) {
		
		DonorBean donorBean = null;
		
		String donorId = null;
		int option = 0;
		
		while(true)
		{
		System.out.println();
		System.out.println();
		System.out.println("    ICARE CAPGEMINI TRUST   \n");
		System.out.println("1.Add Donor");
		System.out.println("2.View Donor");
		System.out.println("3.Retrieve All");
		System.out.println("4.Exit");
		System.out.println("_______________________________");
		System.out.println("Select An Option:");
		
		
		try
		{
			option = sc.nextInt();
			switch(option)
			{
			case 1:
					while(donorBean==null)
					{
						donorBean= populateDonorBean();
					
					try
					{
						donorService = new DonorServiceImpl();
					donorId=donorService.addDonor(donorBean);
					System.out.println("Donor Details has been successfully registered");
					System.out.println("Donor Id is:"+donorId);
					}catch(DonorException donorException)
					{
						System.err.println("Error :"+ donorException.getMessage());
					}finally{
						donorId = null;
						donorService = null;
						donorBean = null;
					}
					}
					
					break;
			case 2:
					
						try
						{
							donorService = new DonorServiceImpl();
							String a=sc.next();
							donorService.viewDonorDetails(a);
						}
					catch(Exception e)
						{
							e.printStackTrace();
						}
				
					break;
			case 3:
				
					break;
			case 4:
				
					break;
			default:
				break;
			}
			}catch(Exception e)
		{
				e.printStackTrace();
				System.err.println(e);
		}
		}
	}

	private static DonorBean populateDonorBean() {
		
		DonorBean donorBean = new DonorBean();
		System.out.println("\nEnter Details");
		
		System.out.println("Enter donor Name:");
		donorBean.setDonorName(sc.next());
		
		System.out.println("Enter the contact");
		donorBean.setPhoneNumber(sc.next());
		
		System.out.println("Enter the address:");
		donorBean.setAddress(sc.next());
		
		System.out.println("Enter the donation amount:");
		try {
			donorBean.setDonationAmount(sc.nextDouble());
			
		}catch(InputMismatchException ime)
		{
			sc.nextLine();
			System.err.println("Please enter a numeric value for the donation amount, try again");
		}
		donorServiceImpl=new DonorServiceImpl();
		try 
		{
			donorServiceImpl.validateDonor(donorBean);
			return donorBean;
		}catch(DonorException donorException)
		{
			donorException.printStackTrace();
			System.err.println("Invalid data");
			System.err.println(donorException.getMessage()+"\n Try Again..");
			System.exit(0);
		}
		return null;
	}
}









