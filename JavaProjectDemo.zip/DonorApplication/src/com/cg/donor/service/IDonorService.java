package com.cg.donor.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;

public interface IDonorService {
	
	public String addDonor(DonorBean donor) throws DonorException, ClassNotFoundException, SQLException, IOException;
	public DonorBean viewDonorDetails(String donorId) throws DonorException, IOException;
	public List retrieveAll() throws DonorException;
	
}
