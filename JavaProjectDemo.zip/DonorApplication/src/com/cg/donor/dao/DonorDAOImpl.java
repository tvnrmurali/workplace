package com.cg.donor.dao;


import java.awt.geom.RectangularShape;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.donor.bean.DonorBean;
import com.cg.donor.exception.DonorException;
import com.cg.donor.util.DBConnection;

public class DonorDAOImpl implements IDonorDAO{

	@Override
	public String addDonor(DonorBean donor) throws ClassNotFoundException, SQLException, IOException {
		
		Connection connection = DBConnection.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		String donorId=null;
//		int queryResult=0;

		try
		{
			preparedStatement = connection.prepareStatement("insert into Donor_Details values(donorId_sequenc.nextVal,?,?,?,sysdate,?)");
			preparedStatement.setString(1,donor.getDonorName());
			preparedStatement.setString(2,donor.getAddress());
			preparedStatement.setString(3,donor.getPhoneNumber());
			preparedStatement.setDouble(4,donor.getDonationAmount());
			
			preparedStatement.executeUpdate();
			Statement st = connection.createStatement();
			resultSet = st.executeQuery("select * from Donor_Details order by donor_id");
			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
			}
			
		return donorId;
		}catch(SQLException sqle)
		{
			sqle.printStackTrace();
			System.out.println(sqle);
		}
		
		return null;
	}

	@Override
	public DonorBean viewDonorDetails(String donorId) throws DonorException, IOException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getConnection();
		String a=donorId;
		try {
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("Select * from Donor_Details where donor_Id='"+a+"'");
					while(rs.next())
					{
						System.out.println(rs.getString(1));
						System.out.println(rs.getString(2));
						System.out.println(rs.getString(3));
						System.out.println(rs.getString(4));
						System.out.println(rs.getDate(5));
						System.out.println(rs.getDouble(6));
					}
		}catch(SQLException sqle)
		{
			sqle.printStackTrace();
		}
		return null;
	}

	@Override
	public List retrieveAll() throws DonorException {
		// TODO Auto-generated method stub
		return null;
	}

}
